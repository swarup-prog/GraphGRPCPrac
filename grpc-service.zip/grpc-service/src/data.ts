let courseData = [
  {
    id: "c1",
    title: "Course 1",
    lessons: 5,
    level: "Beginner",
  },
  {
    id: "c2",
    title: "Course 2",
    lessons: 10,
    level: "Intermediate",
  },
  {
    id: "c3",
    title: "Course 3",
    lessons: 15,
    level: "Advanced",
  },
];

export default courseData;
